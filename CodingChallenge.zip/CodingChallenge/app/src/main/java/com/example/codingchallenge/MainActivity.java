package com.example.codingchallenge;

import android.os.Bundle;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get the RadioButton and set it as checked
        RadioButton nextDayRadioButton = findViewById(R.id.nextday);
        nextDayRadioButton.setChecked(true);
    }
}

